// FRONT IR SENSORS
#define FrontL_ir RB1_bit
#define FrontR_ir RB2_bit

// PARKING IR SENSORS
#define BackR_ir RB3_bit
#define BackL_ir RB4_bit

// WALL AVOIDANCE IR SENSORS
#define WallL_ir RD4_bit
#define WallR_ir RD5_bit

// BUTTON
#define Start_Button RB7_bit

// SERVO MOTOR
#define Servo_45_flag RE1_bit

// SENSOR LOGIC FOR FRONT IR
#define Sensor_on_black 1
#define Sensor_on_white 0

// MOTOR PINS
#define R_IN1 RD0_bit
#define R_IN2 RD1_bit
#define L_IN1 RD2_bit
#define L_IN2 RD3_bit

// BUZZER & LED
#define BUZZER RC0_bit
#define LED RC3_bit

//ULTRASONIC
#define TRIG RA1_bit
#define ECHO RA2_bit

// SPEEDS
#define Normal_speed 150
#define Tunnel_speed 180 // faster than normal speed
#define Parking_speed 120 // slower than normal speed
#define T_correction_speed 110
#define UltraTurn_speed 110
#define IrTurn_speed 140
#define Start_speed 250
//delays and def
#define Start_Delay  150
#define LOOP_DELAY_MS 10
#define LDR_THRESHOLD 450

// ---------------- DELAYS ----------------
void Delay_3s(void)
{
    unsigned char ovf_count = 0;


    T1CON = 0x31;     // Prescaler 1:8, Timer1 ON, Fosc/4


    PIR1 &= 0xFE;     // Clear TMR1IF
    TMR1H = 0x00;
    TMR1L = 0x00;

    while (ovf_count < 12) {
        if (PIR1 & 0x01) {   // TMR1 overflow flag
            PIR1 &= 0xFE;   // Clear flag
            ovf_count++;
        }
    }

    T1CON = 0x00;     // Stop Timer1
}


void Wait_ms(unsigned int ms){
    unsigned int i, j;
    for(i=0;i<ms;i++)
        for(j=0;j<165;j++)
            asm nop;
}

void Delay_us(unsigned int us){
    unsigned int i;
    for(i=0;i<us;i++){
        asm nop; asm nop; asm nop; asm nop;
    }
}

// ---------------- ULTRASONIC ----------------
int distance(){
    unsigned int t = 0;
    unsigned int timeout = 0;

    TRIG = 0;
    Delay_us(2);
    TRIG = 1;
    Delay_us(10);
    TRIG = 0;

    while(!ECHO){
        timeout++;
        if(timeout > 3000) return 999;
    }

    TMR1H = 0;
    TMR1L = 0;
    T1CON |= 0x01;   // Turn Timer1 ON (bad style)

    while(ECHO){
        if((TMR1H<<8 | TMR1L) > 60000){
            T1CON &= 0xFE;   // Turn Timer1 OFF
            return 999;
        }
    }

    T1CON &= 0xFE;   // Turn Timer1 OFF
    t = (TMR1H<<8) | TMR1L;

    return t / 58;
}

// ---------------- PWM ----------------
void PWM_Init(){
    PR2 = 124;
    T2CON = 0b00000111;
    CCP1CON = 0b00001100;
    CCP2CON = 0b00001100;
}

void SetR(unsigned int v){
    v += 23;
    CCPR1L = (v > 1023 ? 1023 : v) >> 2;
}

void SetL(unsigned int v){
    CCPR2L = (v > 1023 ? 1023 : v) >> 2;
}

// ---------------- ADC ----------------
void ADC_Init(){
    ADCON0 = 0b00000001;
    ADCON1 = 0b10000100;
}

unsigned int ReadLDR(){
    GO_DONE_bit = 1;
    while(GO_DONE_bit);
    return (ADRESH<<8) | ADRESL;
}

// ---------------- MOTOR DIR ----------------
void RightForward()
{ R_IN1=1; R_IN2=0;}

void LeftForward()
{ L_IN1=1; L_IN2=0; }

void RightStop()
{ R_IN1=0; R_IN2=0; SetR(0); }

void LeftStop()
{ L_IN1=0; L_IN2=0; SetL(0); }

void StopAll()
{ RightStop(); LeftStop(); }

// ---------------- SERVO ----------------
void RaiseFlag(){
    int i;
    for(i=0;i<50;i++){
        Servo_45_flag=1;
        Delay_us(2000);
        Servo_45_flag=0;
        Delay_us(18000);
    }
}

// ================= MAIN =================
void main(){
    unsigned int ldr, base;
    int object_distance = 999;
    unsigned char ultra_counter = 0;
    unsigned char T_Occured = 0;
    unsigned char intersection = 0;

    TRISB = 0b11111110;
    TRISA = 0b00000101;
    TRISC = 0x00;
    TRISD = 0b00110000;
    TRISE = 0x00;

    PORTA = PORTB = PORTC = PORTD = PORTE = 0;

    T1CON = 0x10;
    PWM_Init();
    ADC_Init();

    while(Start_Button) StopAll();

    Delay_3s();

    LeftForward();
    RightForward();
    SetL(Start_speed);
    SetR(Start_speed);
    Wait_ms(Start_Delay);
    StopAll();

    while(1){

        LED = 1;


        // Parking PatH
        if(BackL_ir==0 && BackR_ir==0 && FrontL_ir==Sensor_on_black && FrontR_ir==Sensor_on_black && T_Occured == 1){

            // Forward 1 second
            LeftForward();
            RightForward();
            SetL(Parking_speed);
            SetR(Parking_speed);
            BUZZER = 1;
            Wait_ms(500);
            BUZZER = 0;
            Wait_ms(500);

            // Right turn 1 second
            LeftStop();
            RightForward();
            SetR(Parking_speed);
            BUZZER = 1;
            Wait_ms(500);
            BUZZER = 0;
            Wait_ms(500);

            // Stop
            StopAll();

            // Flag
            LED = 0;
            RaiseFlag();

            while(1); // breaking out of the loop
        }

        // INTERSECTION
        if(FrontL_ir==Sensor_on_black && FrontR_ir==Sensor_on_black){
            intersection = 1;
            if(!T_Occured){
                StopAll();
                Wait_ms(500);

                LeftStop();
                RightForward();
                SetR(Start_speed);
                Wait_ms(Start_Delay);

                SetR(T_correction_speed);
                Wait_ms(450);

                StopAll();
                Wait_ms(500);

                LeftForward();
                RightForward();
                SetL(Normal_speed);
                SetR(Normal_speed);
                Wait_ms(100);

                T_Occured = 1;
            }
        } else {
            intersection = 0;
        }

        // NO LINE PATH
        if(!intersection){
            ldr = ReadLDR();
            if(ldr < LDR_THRESHOLD){
                BUZZER=1;
                base = Tunnel_speed;
                object_distance = 999;
            } else {
                BUZZER=0;
                base = Normal_speed;

                ultra_counter++;
                if(ultra_counter >= 8){
                    object_distance= distance();
                    ultra_counter = 0;
                }

                if(object_distance > 0 && object_distance < 20){

                    StopAll();
                    Wait_ms(80);

                    if(WallL_ir==0 && WallR_ir==1){
                        LeftStop();
                        RightForward();
                        SetR(UltraTurn_speed);
                        Wait_ms(300);
                    }
                    else if(WallR_ir==0 && WallL_ir==1){
                        LeftForward();
                        RightStop();
                        SetL(UltraTurn_speed);
                        Wait_ms(300);
                    }
                    else{
                        LeftForward();
                        RightStop();
                        SetL(UltraTurn_speed);
                        Wait_ms(300);
                    }

                    StopAll();
                    Wait_ms(100);

                    LeftForward();
                    RightForward();
                    SetL(base);
                    SetR(base);

                    object_distance = 999;
                }
            }

            // LINE FOLLOWINH PATH
            if(FrontL_ir==Sensor_on_white && FrontR_ir==Sensor_on_white){
                LeftForward();
                RightForward();
                SetL(base);
                SetR(base);
            }
            else if(FrontR_ir==Sensor_on_black){
                LeftForward();
                RightStop();
                SetL(IrTurn_speed);
            }
            else if(FrontL_ir==Sensor_on_black){
                LeftStop();
                RightForward();
                SetR(IrTurn_speed);
            }
        }

        Wait_ms(LOOP_DELAY_MS);
    }
}